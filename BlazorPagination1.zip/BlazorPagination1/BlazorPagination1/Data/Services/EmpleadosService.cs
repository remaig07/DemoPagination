﻿using BlazorPagination1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


using System.Data;

namespace BlazorPagination1.Data.Services
{
    public class EmpleadosService : IEmpleadosService
    {
        //Configuramos el contexto de datos para conectarnos a la base de datos
        //que esta declarado en Startup.cs.
       
        public EmpleadosService( )
        {
           
        }
        public Task<Empleado> Actualizar(int id, Empleado empleadoactualizar)
        {
            throw new NotImplementedException();
        }

        public Task<Empleado> Crear(Empleado empleadocrear)
        {
            throw new NotImplementedException();
        }

        public Task<Empleado> Eliminar(int id)
        {
            throw new NotImplementedException();
        }

        public Task<Empleado> ObtenerId(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<List<Empleado>> ObtenerTodos()
        {
            
            List<Empleado> empleadosList = new List<Empleado>();
            Empleado empleado= new Empleado();
            empleado.IntId = 1;
            empleado.StrNombre = "Jose";
            empleado.StrFuncion = "Mora";
            empleado.StrDepartamento = "1";

            empleadosList.Add(empleado);

            Empleado empleado1 = new Empleado();
            empleado1.IntId = 2;
            empleado1.StrNombre = "Pedro";
            empleado1.StrFuncion = "Mora";
            empleado1.StrDepartamento = "2";

            empleadosList.Add(empleado1);

            Empleado empleado2 = new Empleado();
            empleado2.IntId = 3;
            empleado2.StrNombre = "Marco";
            empleado2.StrFuncion = "Castro";
            empleado2.StrDepartamento = "3";

            empleadosList.Add(empleado2);

            Empleado empleado3 = new Empleado();
            empleado3.IntId = 17;
            empleado3.StrNombre = "Al";
            empleado3.StrFuncion = "Castro";
            empleado3.StrDepartamento = "4";

            empleadosList.Add(empleado3);

            Empleado empleado4 = new Empleado();
            empleado4.IntId = 4;
            empleado4.StrNombre = "Jorge";
            empleado4.StrFuncion = "Castro";
            empleado4.StrDepartamento = "3";

            empleadosList.Add(empleado4);

            Empleado empleado5 = new Empleado();
            empleado5.IntId = 5;
            empleado5.StrNombre = "Bryan";
            empleado5.StrFuncion = "Castro";
            empleado5.StrDepartamento = "3";

            empleadosList.Add(empleado5); 
            
            Empleado empleado6 = new Empleado();
            empleado6.IntId = 6;
            empleado6.StrNombre = "Luis";
            empleado6.StrFuncion = "Castro";
            empleado6.StrDepartamento = "3";

            empleadosList.Add(empleado6);

            Empleado empleado7 = new Empleado();
            empleado7.IntId = 7;
            empleado7.StrNombre = "Maria";
            empleado7.StrFuncion = "Castro";
            empleado7.StrDepartamento = "3";

            empleadosList.Add(empleado7); 
            
            Empleado empleado8 = new Empleado();
            empleado8.IntId = 8;
            empleado8.StrNombre = "Jimena";
            empleado8.StrFuncion = "Castro";
            empleado8.StrDepartamento = "3";

            empleadosList.Add(empleado8);

            Empleado empleado9 = new Empleado();
            empleado9.IntId = 9;
            empleado9.StrNombre = "Teresa";
            empleado9.StrFuncion = "Castro";
            empleado9.StrDepartamento = "3";

            empleadosList.Add(empleado9); 
            
            Empleado empleado10 = new Empleado();
            empleado10.IntId = 10;
            empleado10.StrNombre = "Aurelio";
            empleado10.StrFuncion = "Castro";
            empleado10.StrDepartamento = "3";

            empleadosList.Add(empleado10);

            Empleado empleado11 = new Empleado();
            empleado11.IntId = 11;
            empleado11.StrNombre = "Argeri";
            empleado11.StrFuncion = "Castro";
            empleado11.StrDepartamento = "3";

            empleadosList.Add(empleado11); 
            
            Empleado empleado12 = new Empleado();
            empleado12.IntId = 12;
            empleado12.StrNombre = "Veronica";
            empleado12.StrFuncion = "Castro";
            empleado12.StrDepartamento = "3";

            empleadosList.Add(empleado12);

            Empleado empleado13 = new Empleado();
            empleado13.IntId = 13;
            empleado13.StrNombre = "Melissa";
            empleado13.StrFuncion = "Castro";
            empleado13.StrDepartamento = "3";

            empleadosList.Add(empleado13);
            
            Empleado empleado14 = new Empleado();
            empleado14.IntId = 14;
            empleado14.StrNombre = "Karla";
            empleado14.StrFuncion = "Castro";
            empleado14.StrDepartamento = "3";

            empleadosList.Add(empleado14);

            Empleado empleado15 = new Empleado();
            empleado15.IntId = 15;
            empleado15.StrNombre = "Sandra";
            empleado15.StrFuncion = "Castro";
            empleado15.StrDepartamento = "3";

            empleadosList.Add(empleado15); 
            
            Empleado empleado16 = new Empleado();
            empleado16.IntId = 16;
            empleado16.StrNombre = "Marlene";
            empleado16.StrFuncion = "Castro";
            empleado16.StrDepartamento = "3";

            empleadosList.Add(empleado2);

            Empleado empleado172 = new Empleado();
            empleado172.IntId = 17;
            empleado172.StrNombre = "Isaac";
            empleado172.StrFuncion = "Castro";
            empleado172.StrDepartamento = "3";

            empleadosList.Add(empleado172); 
            
            Empleado empleado18 = new Empleado();
            empleado18.IntId = 18;
            empleado18.StrNombre = "Fabio";
            empleado18.StrFuncion = "Castro";
            empleado18.StrDepartamento = "3";

            empleadosList.Add(empleado18);
            //return await _context.Empleados.ToListAsync();

            return empleadosList;
        }

    }
}
